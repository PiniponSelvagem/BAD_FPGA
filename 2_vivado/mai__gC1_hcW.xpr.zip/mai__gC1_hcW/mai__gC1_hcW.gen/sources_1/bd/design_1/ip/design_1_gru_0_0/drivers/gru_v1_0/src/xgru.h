// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1.1 (64-bit)
// Tool Version Limit: 2023.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XGRU_H
#define XGRU_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xgru_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Bus1_BaseAddress;
} XGru_Config;
#endif

typedef struct {
    u64 Bus1_BaseAddress;
    u32 IsReady;
} XGru;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XGru_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XGru_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XGru_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XGru_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XGru_Initialize(XGru *InstancePtr, u16 DeviceId);
XGru_Config* XGru_LookupConfig(u16 DeviceId);
int XGru_CfgInitialize(XGru *InstancePtr, XGru_Config *ConfigPtr);
#else
int XGru_Initialize(XGru *InstancePtr, const char* InstanceName);
int XGru_Release(XGru *InstancePtr);
#endif

void XGru_Start(XGru *InstancePtr);
u32 XGru_IsDone(XGru *InstancePtr);
u32 XGru_IsIdle(XGru *InstancePtr);
u32 XGru_IsReady(XGru *InstancePtr);
void XGru_EnableAutoRestart(XGru *InstancePtr);
void XGru_DisableAutoRestart(XGru *InstancePtr);

void XGru_Set_layerIndex(XGru *InstancePtr, u32 Data);
u32 XGru_Get_layerIndex(XGru *InstancePtr);

void XGru_InterruptGlobalEnable(XGru *InstancePtr);
void XGru_InterruptGlobalDisable(XGru *InstancePtr);
void XGru_InterruptEnable(XGru *InstancePtr, u32 Mask);
void XGru_InterruptDisable(XGru *InstancePtr, u32 Mask);
void XGru_InterruptClear(XGru *InstancePtr, u32 Mask);
u32 XGru_InterruptGetEnabled(XGru *InstancePtr);
u32 XGru_InterruptGetStatus(XGru *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
